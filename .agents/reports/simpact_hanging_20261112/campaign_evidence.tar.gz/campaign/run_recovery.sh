#!/usr/bin/env bash
# Main launches this ONLY after job 5213853 auto-releases and the original
# planning/result.json reports the guarded all-ten-rejected terminal case:
# salloc --account=ehpc-dev-2026d08-170-gpu --partition=gpu \
#   --gres=gpu:nvidia_gh200_120gb:1 --cpus-per-task=8 --mem=32G \
#   --time=12:00:00 --kill-command=TERM bash /absolute/path/to/run_recovery.sh
set -euo pipefail
: "${SLURM_JOB_ID:?Launch inside the new Slurm allocation after the original job ends}"
simpact_root=/nobackup/proj/disk/ehpc-dev-2026d08-170/personal/yiduo/simpact-integration-20261110/part-aware-sim-control
cd "$simpact_root"
export PYTHONPATH="$simpact_root:$simpact_root/../newton:$simpact_root/../simpact"
export WARP_CACHE_PATH=/nobackup/proj/disk/ehpc-dev-2026d08-170/personal/yiduo/newton/.cache/warp
export ROBOSIMSTUDIO_RENDERER=tiled
export OMP_NUM_THREADS=8
/tmp/simpact-planner-venv/bin/python -u outputs/simpact/hanging_loop_tail_20261112/continue_rejected_batch.py \
  > outputs/simpact/hanging_loop_tail_20261112/recovery_planner.log 2>&1

# Decode the final recorded attempt before releasing this allocation.
srun --nodes=1 --ntasks=1 --cpus-per-task=1 /nobackup/proj/disk/ehpc-dev-2026d08-170/personal/yiduo/newton/.venv/lib/python3.12/site-packages/imageio_ffmpeg/binaries/ffmpeg-linux-aarch64-v7.0.2 -hide_banner \
  -i /nobackup/proj/disk/ehpc-dev-2026d08-170/personal/yiduo/simpact-integration-20261110/part-aware-sim-control/outputs/simpact/hanging_loop_tail_20261112/recovery/rollouts/attempt_012/replay.mp4 -f null - \
  > /nobackup/proj/disk/ehpc-dev-2026d08-170/personal/yiduo/simpact-integration-20261110/part-aware-sim-control/outputs/simpact/hanging_loop_tail_20261112/video_validation_final.log 2>&1
