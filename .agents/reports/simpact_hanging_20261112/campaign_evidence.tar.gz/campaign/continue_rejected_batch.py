"""One-off continuation of this exact all-rejected batch; never rerun its initial ten.

Run only after the original job has terminated with the guarded no-executable
error. This is an operational recovery, not a public resume API or new campaign.
"""

from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

CAMPAIGN = Path(__file__).resolve().parent
ROOT = CAMPAIGN.parents[2]
ORIGINAL = CAMPAIGN / "planning"
RECOVERY = CAMPAIGN / "recovery"
ARM_PYTHON = ROOT.parent.parent / "newton/.venv/bin/python"
MODEL = "gpt-6-sol"
PROFILE = "clawhauser_hang"
# Frozen when this recovery script was prepared, before the initial batch ended.
INPUT_HASHES = {
    "planning/vlm/response_000_propose.txt": "9a8db5857571dd428d9fac3960515ffeec4dec9c2a64723be4e7fdccaa0ae302",
    "planning/proposals.json": "4a092398612bf1aac0dd327a5f9cd99f4c8ef4ebe56b49e2d739c93a9c485215",
    "observation/observation.json": "569fc42c9185f138bbc6c8fc9cec996fd40713e9221aa7ff8f51031c89955042",
    "task.json": "3e08b6e7c7a80a8cb54269d4de7846c68a7192a168eea1920780f25a862254ba",
    "planning/task.json": "3e08b6e7c7a80a8cb54269d4de7846c68a7192a168eea1920780f25a862254ba",
    "planning/rollouts/rollout_reference_baseline.json": "bb69d342b6cb42b957c12168bd79d3dc21be410cbcd48372d09a84459c8352b2"
}


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source(path):
    return {"path": str(path), "sha256": digest(path)}


def main():
    assert not RECOVERY.exists(), "recovery already exists; do not repeat this continuation"
    for relative, expected in INPUT_HASHES.items():
        assert digest(CAMPAIGN / relative) == expected, f"original input changed: {relative}"
    for name in ("rollout.py", "tasks.py", "hanging.py"):
        current = ROOT / "part_aware_control" / name
        frozen = CAMPAIGN / "source_snapshot/part_aware_control" / name
        assert digest(current) == digest(frozen), f"frozen simulation source changed: {name}"

    old = read(ORIGINAL / "result.json")
    assert old["status"] == "error" and not old["success"]
    assert old["error"] == {
        "type": "ValueError", "message": "no initial proposal could be executed; optimization cannot start"
    }, "original run did not stop at the exact all-rejected initial-batch error"
    assert old["planning_rollouts_attempted"] == old["actual_proposal_count"] == 10
    assert old["planning_rollouts_completed"] == old["refinement_iterations"] == 0
    assert old["confirmation_rollouts_attempted"] == 0 and not old["attempts"]
    assert len(old["invalid_proposals"]) == 10
    assert sorted(p["index"] for p in old["invalid_proposals"]) == list(range(10))
    assert old.get("planning_rollouts_rejected", 0) in (0, 10)  # Old loaded code had no rejection counter.
    assert old["provider"] == "codex" and old["model"] == MODEL
    assert old["task"]["name"] == PROFILE and old["max_refinement_iterations"] == 3
    original_calls = read(ORIGINAL / "vlm/vlm_calls.json")
    assert len(original_calls) == 1 and original_calls[0]["stage"] == "propose"
    assert original_calls[0]["proposal_count"] == 10 and not original_calls[0].get("error")
    raw_path = ORIGINAL / "vlm/response_000_propose.txt"
    assert Path(original_calls[0]["response_path"]).resolve() == raw_path.resolve()

    from part_aware_control.actions import InvalidPlan, normalize_plan
    from part_aware_control.planner import rejected_rollout, run_planning
    from part_aware_control.providers import make_codex_generate_fn
    from simpact.actions import ProposalSet
    from simpact.generator.propose import VLMProposer
    from simpact.generator.vlm import strip_json_fences

    raw = raw_path.read_text()
    proposals = ProposalSet.from_dict(json.loads(strip_json_fences(raw)))
    assert len(proposals.action_proposals) == 10
    assert not proposals.validate(allowed_types={"move", "gripper_control"})
    assert proposals.to_dict() == read(ORIGINAL / "proposals.json")
    errors = []
    for index, plan in enumerate(proposals.action_proposals):
        directory = ORIGINAL / "rollouts" / f"attempt_{index:03d}"
        assert plan.to_dict() == read(directory / "plan.json"), f"initial plan {index} differs"
        error = read(directory / "error.json")
        assert error["type"] == "InvalidPlan" and not (directory / "rollout.json").exists()
        errors.append(error)
    observation_path = CAMPAIGN / "observation/observation.json"
    observation = read(observation_path)
    assert observation["task"] == read(CAMPAIGN / "task.json") == read(ORIGINAL / "task.json") == old["task"]
    assert read(ORIGINAL / "observation.json") == observation
    templates = {stage: ROOT / f"part_aware_control/prompts/hang_{stage}.txt" for stage in ("propose", "refine", "verify")}
    assert digest(templates["propose"]) == digest(CAMPAIGN / "source_snapshot/part_aware_control/prompts/hang_propose.txt")
    initial = observation["snapshots"][0]
    context = (
        "Known privileged simulation state, not a perception/reconstruction result.\n"
        "World-frame metres, right-handed rotations in radians, quaternion xyzw, total jaw opening.\n"
        + json.dumps({"task": observation["task"], "geometry": observation["geometry"], "initial_state": initial})
    )
    expected_propose = VLMProposer(prompt_template=str(templates["propose"])).build_prompt(
        old["instruction"], observation_path.parent / initial["screenshot"], context=context
    )

    RECOVERY.mkdir()
    shutil.copyfile(ORIGINAL / "result.json", RECOVERY / "original_error_result.json")
    snapshot = RECOVERY / "source_snapshot"
    files = [ROOT / f"part_aware_control/{name}" for name in ("planner.py", "providers.py", "__main__.py", "actions.py", "rollout.py", "tasks.py", "hanging.py")]
    files += list(templates.values())
    for path in files:
        target = snapshot / path.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
    provenance = {
        "operation": "continue exact original all-rejected batch with cached proposals and partial evidence",
        "provider": "codex", "model": MODEL, "profile": PROFILE,
        "original_error_result": source(ORIGINAL / "result.json"),
        "original_raw_proposal": source(raw_path), "original_observation": source(observation_path),
        "original_task": source(CAMPAIGN / "task.json"),
        "frozen_physics_sources": [source(ROOT / "part_aware_control" / name) for name in ("rollout.py", "tasks.py", "hanging.py")],
        "current_sources": [source(path) for path in files],
        "revisions": observation["revisions"],
        "controller_git_head": subprocess.check_output(["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True).strip(),
        "initial_partial_attempts_reused": 10, "new_initial_executions": 0,
        "new_initial_proposal_api_calls": 0, "original_rejections_confirmed": 10,
        "max_campaign_planning_attempts": 13, "max_successful_plan_confirmations": 1,
    }
    write(RECOVERY / "provenance.json", provenance)
    call_provenance = []
    cached_indices = []
    new_worker_calls = []

    def generate(contents):
        if not call_provenance:
            assert len(contents) == 2 and contents[1] == expected_propose, "cached proposal prompt identity changed"
            call_provenance.append({"stage": "propose", "api_call": False, "cached_response": source(raw_path)})
            return raw
        # Exact template text, not substring heuristics, chooses the real call.
        stage = next((s for s in ("verify", "refine") if contents[0] == templates[s].read_text()), None)
        assert stage is not None, "unexpected generation stage; a second initial proposal call is forbidden"
        call_provenance.append({"stage": stage, "api_call": True, "template": source(templates[stage])})
        return make_codex_generate_fn(MODEL, stage, profile=PROFILE)(contents)

    def rollout(plan, index, out_dir):
        directory = Path(out_dir)
        directory.mkdir(parents=True, exist_ok=True)
        write(directory / "plan.json", plan.to_dict())
        confirmation = directory.parent.name == "confirmation"
        if not confirmation and index < 10:
            assert index == len(cached_indices), "initial evidence must be replayed once in proposal order"
            original_directory = ORIGINAL / "rollouts" / f"attempt_{index:03d}"
            assert plan.to_dict() == read(original_directory / "plan.json") == proposals.action_proposals[index].to_dict()
            if index == 0:
                baseline_path = ORIGINAL / "rollouts/rollout_reference_baseline.json"
                baseline = read(baseline_path)
                baseline["evidence_source"] = "Separately authored explicit reference baseline; not a model candidate or a new execution."
                baseline["recovery_provenance"] = source(baseline_path)
                write(directory.parent / "rollout_reference_baseline.json", baseline)
            error_path = original_directory / "error.json"
            shutil.copyfile(error_path, directory / "original_error.json")
            path = rejected_rollout(errors[index], plan, observation, directory)
            data = read(path)
            data["evidence_source"] = "Original initial model candidate rejected during execution; cached partial evidence, no repeated simulation."
            data["recovery_provenance"] = {"original_index": index, "new_simulation_execution": False,
                                           "original_error": source(error_path), "original_plan": source(original_directory / "plan.json")}
            write(path, data)
            cached_indices.append(index)
            return path
        assert cached_indices == list(range(10)), "all original evidence must precede new simulation"
        assert confirmation or 10 <= index <= 12, "refinement execution exceeds original budget"
        if confirmation:
            assert not any(c["confirmation"] for c in new_worker_calls), "only one confirmation allowed"
        try:
            normalize_plan(plan)
        except InvalidPlan as error:
            return rejected_rollout({"type": "InvalidPlan", "message": str(error)}, plan, observation, directory)
        new_worker_calls.append({"index": index, "confirmation": confirmation, "directory": str(directory)})
        command = ["srun", "--nodes=1", "--ntasks=1", "--cpus-per-task=8", str(ARM_PYTHON), "-u", "-m", "part_aware_control",
                   "worker", "--video", "--index", str(index), "--task-config", str(CAMPAIGN / "task.json"),
                   "--plan", str(directory / "plan.json"), "--out", str(directory)]
        with (directory / "worker.log").open("w") as log:
            process = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=False)
        if process.returncode:
            error_path = directory / "error.json"
            if error_path.exists() and read(error_path)["type"] == "InvalidPlan":
                return rejected_rollout(read(error_path), plan, observation, directory)
            raise RuntimeError(f"simulator worker failed; see {directory / 'worker.log'}")
        return directory / "rollout.json"

    result = run_planning(observation_json=observation_path, instruction=old["instruction"], out_dir=RECOVERY,
                          rollout_fn=rollout, provider="codex", model=MODEL, generate_fn=generate)
    events_path = RECOVERY / "vlm/vlm_calls.json"
    events = read(events_path) if events_path.exists() else []
    assert len(events) == len(call_provenance), "VLM provenance/event counts differ"
    for event, extra in zip(events, call_provenance):
        assert event["stage"] == extra["stage"]
        event.update(extra, provider="codex", model=MODEL)
    if events_path.exists():
        write(events_path, events)
    actual_calls = [dict(original_calls[0], provider="codex", model=MODEL, api_call=True, phase="original_initial_batch")]
    actual_calls += [dict(event, phase="recovery") for event in events if event["api_call"]]
    write(CAMPAIGN / "campaign_vlm_calls.json", actual_calls)
    result["continuation"] = {**provenance, "cached_initial_evidence_callbacks": len(cached_indices),
                              "new_worker_calls": new_worker_calls, "actual_campaign_vlm_calls": len(actual_calls)}
    write(RECOVERY / "result.json", result)
    print(json.dumps(result, indent=2))
    return 2 if result["status"] == "error" else 0


if __name__ == "__main__":
    sys.exit(main())
