# SIMPACT Clawhauser hanging — implementation and experiment

Requested 12 November 2026: pull Hanson's new main, then try a complete
SIMPACT-style VLM optimization campaign for hanging the toy's ring on the rod.
Work autonomously, preserve the simple integration, and test only core behavior.

## Source and constraints

- Integration branch: yiduo/simpact-integration-20261110, fast-forwarded from
  2fe88f4 to origin/main 3393ff5 (Hanson heterogeneous-tests 650015e).
- New upstream changes include arm MOUNT=(-0.05,-0.42,0.232), tail grasp options,
  trajectory joint angles and a revised bottle scene. Use the default loop grasp
  for this task; do not replace the fully deformable toy or tune its materials.
- Reuse clawhauser_on_rod.build_scene defaults, including the 6 mm rod, original
  label identities, 60 Hz/20 substeps/Chebyshev160, contact/self-contact settings,
  force limits and existing AIRBOT hand. Native example motions are a separately
  labelled reference; its measured turn/thread callbacks are not VLM actions.
- Newton remains 5cd406a1 after a fresh fetch; pinned SIMPACT 692aab2b stays fixed.
- Existing saved Codex login and exact gpt-6-sol. Ten full initial plans, at most
  three one-plan refinements, one fresh confirmation only after planning success.
  No Google key, provider substitution or extra optimization campaigns.

## Implementation

1. Run the unmodified Hanson loop-grasp example on an allocated ARM GH200, with
   video, and preserve its result/diagnostics/configuration. Already submitted
   under outputs/simpact/hanging_hanson_reference_20261112.
2. Add task clawhauser_hang. Reuse the native builder, expose rod endpoints/axis,
   ring inner center/normal, source settings, pad offset and common fresh pose.
3. Add compact per-control-frame hanging measurements using Hanson's penetration
   and mixed-stiffness support calculation: loop/rod contacts, upward rod support,
   finger contact, actual hole pose, engagement and collision depth. Keep the
   existing mesh-quality substep latch and record waypoint feedback.
4. Use existing lowercase six-axis move and gripper_control for both proposal and
   refinement stages of this task; preserve placement profiles. Turns must be
   physically commanded, with reachable orientations and consistent TCP/pad
   geometry. No attachments, implicit grasp, auto alignment or scripted thread.
5. Hanging success requires rod support >=90%weight, actual loop/rod contact,
   absolute winding >=0.5 of the ordered material inner-hole contour around the
   rod axis, its entire contour >=10mm inboard of the tip and <=rod length,
   >=20 mm whole-toy table clearance, no final
   finger contact, released jaws, stable final half-second, valid mesh and the
   reference's <=0.5 mm contact penetration. Freeze thresholds before the model
   campaign; do not weaken them to obtain success.
6. Add hanging-specific propose/refine/verify prompts so airborne rod-supported
   success is accepted. Model receives measured failures and supplies every
   action of every independent fresh-scene sequence.

## Core validation and experiment

- Reuse existing ten offline checks. Add only focused pose/profile and hanging
  gate checks that reject a toy on the table, a toy still held by fingers, or an
  invalid/disengaged mesh. Ruff on changed files; no broad new test framework.
- Inspect the native reference, then execute an explicit baseline through our
  worker when its pose commands can be derived from the saved reference. Any
  reference feedback used to author that input is labelled separately.
- Obtain our own common initial observation. Execute all ten generated plans,
  verify in order, refine up to three times with accumulated evidence, then
  confirm the first verified success in a fresh scene. Preserve failure if the
  budget is exhausted; the goal is to try the specified campaign honestly.
- Save raw model calls, task/geometry/revisions, plans, measured outcomes,
  screenshots, timing and continuous videos. Distinguish errors from physical
  failures, and reference motions from model-generated solutions.
- Use x86 planner and srun ARM workers. Tie each Slurm allocation to its command
  with salloc --kill-command=TERM so completion/failure releases the GPU.
- Independently review the adapter, gating and final experimental evidence.

## Status

Main update and implementation complete. Twelve focused checks and Ruff pass;
independent review accepted native defaults, observations, pose execution,
planner profile/budget, winding/finite-rod checks and task-specific CLI instruction.

Native reference job5212884 completed and released its allocation. Native default
loop-grasp run failed: no final rod support, toy fell, max contact penetration
1.74791mm, two BODY inverted element-substeps. This is not a model attempt.
An initial adapter observation completed successfully; the actual campaign will
obtain a fresh observation with the final winding schema before generating plans.

Actual experiment output: outputs/simpact/hanging_loop_tail_20261112. The explicit
baseline input is authored from the saved native trajectory's TCP poses, with
recorded initial settled-grasp compensation. This static baseline has no runtime
turn/thread correction, and is not guaranteed to reproduce a feedback demo.
It is separate from the ten model-generated candidates.

Preflight allocation5213382 was cancelled after6m50s before any model call. It
exposed a controller contract issue: every move interpolated jaw targets from
measured rather than previous commanded opening, briefly unloading a stalled
pinch. Independent source review confirmed the native demo explicitly avoids this.
Hanging moves now preserve the commanded jaw target; placement behavior is kept.
Measured and commanded openings are recorded separately. The cancelled baseline
is retained in outputs/simpact/hanging_codex_20261112 and is not a model attempt.

The final campaign exposes both loop and tail source grasp locations and distinct
settled part shifts, as supported by Hanson's latest code. Choosing a pickup part
does not alter the physical scene; the final support must still be the loop on
the rod. All original acceptance thresholds and the10+3budget remain fixed.
A fresh observation and28-action explicit loop baseline will run with the final
controller before the model campaign. The x86 planner then runs automatically
with gpt-6-sol and all workers record continuous video. Code snapshots and
experiment metadata are saved alongside each run.
