#!/usr/bin/env bash
set -euo pipefail
simpact_root=/nobackup/proj/disk/ehpc-dev-2026d08-170/personal/yiduo/simpact-integration-20261110/part-aware-sim-control
simpact_arm_python=/nobackup/proj/disk/ehpc-dev-2026d08-170/personal/yiduo/newton/.venv/bin/python
simpact_planner_python=/tmp/simpact-planner-venv/bin/python
cd "$simpact_root"
export PYTHONPATH="$simpact_root:$simpact_root/../newton:$simpact_root/../simpact"
export WARP_CACHE_PATH=/nobackup/proj/disk/ehpc-dev-2026d08-170/personal/yiduo/newton/.cache/warp
export ROBOSIMSTUDIO_RENDERER=tiled
export OMP_NUM_THREADS=8
srun --nodes=1 --ntasks=1 --cpus-per-task=8 "$simpact_arm_python" -u -m part_aware_control observe \
  --task clawhauser_hang --out outputs/simpact/hanging_loop_tail_20261112/observation \
  > outputs/simpact/hanging_loop_tail_20261112/observation.log 2>&1
"$simpact_planner_python" outputs/simpact/hanging_loop_tail_20261112/author_reference_plan.py \
  > outputs/simpact/hanging_loop_tail_20261112/baseline_authoring.log 2>&1
srun --nodes=1 --ntasks=1 --cpus-per-task=8 "$simpact_arm_python" -u -m part_aware_control worker --video \
  --task-config outputs/simpact/hanging_loop_tail_20261112/task.json \
  --plan outputs/simpact/hanging_loop_tail_20261112/baseline_plan.json \
  --out outputs/simpact/hanging_loop_tail_20261112/baseline \
  > outputs/simpact/hanging_loop_tail_20261112/baseline.log 2>&1
"$simpact_planner_python" -u -m part_aware_control plan \
  --observation outputs/simpact/hanging_loop_tail_20261112/observation/observation.json \
  --instruction 'Pick up Clawhauser using a loop OR tail grasp from the supplied candidates, lift it clear, orient the ring hole toward the horizontal rod, thread the hole beyond the rod free end, transfer the weight onto the rod, release and withdraw so the toy remains hanging. Supply every action explicitly. The current native loop-grasp reference jammed against the rod, exceeded 0.5 mm penetration, and dropped the toy after release; avoid side-loading the rod or assuming that the deformed hole follows the TCP exactly. Keep the supplied frozen physical gates.' \
  --worker-command "srun --nodes=1 --ntasks=1 --cpus-per-task=8 $simpact_arm_python -u -m part_aware_control --video" \
  --provider codex --model gpt-6-sol --out outputs/simpact/hanging_loop_tail_20261112/planning \
  > outputs/simpact/hanging_loop_tail_20261112/planner.log 2>&1
