"""Author an explicit baseline from Hanson's saved trajectory; no runtime correction."""
import json
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation

root = Path.cwd()
reference = root / 'outputs/simpact/hanging_hanson_reference_20261112'
out = root / 'outputs/simpact/hanging_loop_tail_20261112'
observation = json.loads((out / 'observation/observation.json').read_text())
trajectory = np.load(reference / 'reference/trajectory.npz')
body_ids = [i for i, name in enumerate(trajectory['body_label']) if str(name).endswith('/link6') or str(name) == 'link6']
if len(body_ids) != 1:
    raise RuntimeError(f'expected one AIRBOT link6, found {body_ids}')
body = trajectory['body_q'][:, body_ids[0]]
times = trajectory['time']
geometry = observation['geometry']
initial = observation['snapshots'][0]
name = observation['task']['name']
position = np.asarray(initial['gripper']['position'], dtype=float)
orientation = Rotation.from_quat(initial['gripper']['orientation'])
actions = []

def pose_at(time_s):
    frame = int(np.argmin(np.abs(times-time_s)))
    rotation = Rotation.from_quat(body[frame, 3:7])
    return body[frame, :3] + rotation.apply([0,0,0.005]), rotation

def move_to(target, rotation, duration):
    global position, orientation
    delta = np.asarray(target)-position
    angles = (rotation*orientation.inv()).as_euler('xyz')
    action = dict(type='move',delta_x=float(delta[0]),delta_y=float(delta[1]),delta_z=float(delta[2]),delta_roll=float(angles[0]),delta_pitch=float(angles[1]),delta_yaw=float(angles[2]),duration=float(duration))
    actions.append(action)
    position, orientation = np.asarray(target),rotation

grasp = np.asarray(geometry['nominal_grip_centre_world_m'])+np.asarray(geometry['tcp_for_pads_offset_world_m'])+np.asarray(initial['objects'][name]['settled_loop_shift_m'])
move_to([grasp[0],grasp[1],position[2]],orientation,0.8)
move_to(grasp,orientation,max(0.8,abs(grasp[2]-position[2])/0.06))
closed = max(0.0,2*(geometry['reach_m']-geometry['grip_squeeze_m']))
actions.append(dict(type='gripper_control',width=closed,duration=0.6))
native_grasp,_ = pose_at(1.05)
shift = grasp-native_grasp
shift[2] = 0
last_time = 1.05
for time_s in [1.1,2.1,3.1,4.1,5.1,5.9,6.15,6.4,6.65,6.9,7.15,7.4,7.65,7.9,8.4,9.2,9.4,10.2,11.0,11.4,11.9,12.2]:
    target,rotation = pose_at(time_s)
    # Initial settled-aim difference is explicit in the baseline's lift/turn;
    # the recorded thread target stays at the fixed rod.
    factor = 1.0 if time_s <= 8.4 else max(0.0,(9.2-time_s)/0.8)
    move_to(target+factor*shift,rotation,max(0.1,time_s-last_time))
    last_time=time_s
actions.append(dict(type='gripper_control',width=geometry['max_aperture_m'],duration=0.6))
for time_s,duration in [(12.9,0.2),(13.5,0.6)]:
    target,rotation=pose_at(time_s)
    move_to(target,rotation,duration)
plan={'description':'Explicit static baseline authored from saved Hanson loop demo TCP poses; no feedback in execution','action_sequence':actions,'source_reference':str(reference/'reference/trajectory.npz'),'settled_grasp_shift_m':shift.tolist()}
(out/'baseline_plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(out/'task.json').write_text(json.dumps(observation['task'],indent=2)+'\n')
print(json.dumps({'baseline_actions':len(actions),'task':observation['task'],'plan':str(out/'baseline_plan.json')}))
